This is a menu program!

Build Procedure
	$ gcc linklist.c SE_Lab2.c -o SE_Lab2
	$ ./SE_Lab2 # you can input help & version & writer cmd.
