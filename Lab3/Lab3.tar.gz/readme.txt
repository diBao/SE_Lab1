This is a menu test program!

Build Procedure
	$ mark all
    $ ./test
